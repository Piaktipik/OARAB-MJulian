YeeLinkLib
==========
FIRSTLY, ANYONE can use & distribute this software under the GPLv3.

yeelink is a professional platform of the Internet of Things.It provides stable & high-quality service. 
Unfortunately its development environment is not so good，even no offical sdk. So I made one.
yeelink supports various hardware by which U can communicate with yeelink，i don't think i can enumerate all of them.
Now this lib just supports Arduino + W5100——my favorite composition ^_^
