Debug note（调试心得）
=======

1. Do not put DSM501 in sun. (不要让传感器DSM501暴露在阳光下工作)
2. Do not put DSM501 in LED light. （不要让DSM501暴露在LED灯、日光灯下工作）
3. Must be use a good quality supply power. （必须使用好的电源，比如手机电源适配器5V给arduino和DMS501供电）

That is all, if not, PM2.5 data will very big.

