/** Automatically generated file. DO NOT MODIFY */
package hmm.sensortest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}