flashlight demo
=======
thanks huahua.
build from http://blog.csdn.net/huahuadashen/article/details/22284011
more detail see also http://blog.csdn.net/huahuadashen/article/details/22284011