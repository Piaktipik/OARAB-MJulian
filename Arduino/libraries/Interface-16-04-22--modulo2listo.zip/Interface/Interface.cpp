
//#include "Arduino.h"
#include "Interface.h"

// definicion metodos miembro clase Interface
Interface::Interface() {
  buffer_datos_recividos = 100;
  depuracion =  false;
  comunicacionNRF24L01 =  false;
  /* Hardware configuration: Set up nRF24L01 radio on SPI bus plus pins 7 & 8 */
  radio.init(7, 8);
  conectado = false;
  publicado =  false;
}

void Interface::revisarInterface() {
  if (!publicado) {
    publicacion();
    procesarMensaje();
  } else {
    //revisarVariablesEstado();
    //procesarOrdenesInterface();
    // se procesa la peticion de la interface
    String funcionRequerida = procesarMensaje();

    for (int i = 0; i < contadorFuncionesCargadas; i++ ) {
      if (nombreFunciones[i] == funcionRequerida)
        (*apuntadoresFunciones[i])();
    }
  }
}

void Interface::publicacion() {
  if (!conectado) {
    String direccionstring = uint64tostring(addresses[1]);
    enviarMensaje("HOLA-" + direccionstring);
  } else if (!publicado) {
    enviar_identificacion();
  }
}

String Interface::procesarMensaje() {
  unsigned long tiempoReintentando = millis();
  String datos = "";
  while ((datos == "") && millis() < tiempoReintentando + 200) {
    datos = recivirStringNrf24l01();

    // si hay mensaje valido
    if (datos != "") {

      if (datos[0] == '{') {
        return obtenerFuncionJson(datos);

      } else if (datos == "HOLA-IDENTIFICATE") {
        conectado = true;

      } else if (datos == "BIENVENIDO") {
        publicado = true;

      }

    } // fin if mensaje valido
  } // fin while escucha

  return datos;
}

String Interface::obtenerFuncionJson(String datos) {
  StaticJsonBuffer<100> jsonBuffer;
  JsonObject& root = jsonBuffer.parseObject(datos);
  // Test if parsing succeeds.
  if (root.success()) {
    (*serialDepuracion).println("ParseObject() ok ");

    String sensor = root["Sensor"];
    long tiempo = root["Tiempo"];
    String funcion = root["Funcion"];

    // Print values.
    (*serialDepuracion).print(sensor);
    (*serialDepuracion).print(tiempo);
    (*serialDepuracion).println(funcion);
    if (depuracion) {(*serialDepuracion).println();}
    return funcion;
  } else {
    (*serialDepuracion).println("ParseObject() failed");
  }
  if (depuracion) {(*serialDepuracion).println();}
  return "";
}


void Interface::agregarObjeto(const String nombreObjetoCargar, bool esHermano) {
  if (depuracion) {
    (*serialDepuracion).print("Cargando Objeto: ");
    (*serialDepuracion).print(nombreObjetoCargar);
  }

  nombreObjetos[contadorObjetosCargados] = nombreObjetoCargar;
  ObjetosHermanos[contadorObjetosCargados] = esHermano; // me permite crear objetos hermanos ya que por defecto son hijos del objeto anterior
  objetoActual = nombreObjetoCargar;

  // el primer objeto agregado no puede ser hermnano
  if (contadorObjetosCargados == 0) {
    ObjetosHermanos[contadorObjetosCargados] = false;
  }
  contadorObjetosCargados++;
  if (depuracion)(*serialDepuracion).println(" ...Cargado");
}

void Interface::agregarFuncion(String nombreFuncion, void (*apuntadorFuncion)()) {
  if (depuracion) {
    (*serialDepuracion).print("Cargando Funcion: ");
    (*serialDepuracion).print(nombreFuncion);
  }
  if (objetoActual != "") {
    // cargamos la funcion al vector de apuntadores a funciones
    apuntadoresFunciones[contadorFuncionesCargadas] = apuntadorFuncion;     // guardamos el apuntador a la funcion
    nombreFunciones[contadorFuncionesCargadas] = nombreFuncion;             // guardamos el nombre de la funcion
    nombreObjetosFuncion[contadorFuncionesCargadas] = objetoActual;         // asignamos esta funcion a un objeto
    contadorFuncionesCargadas++;
    if (depuracion)(*serialDepuracion).println(" ...Cargada");
  } else {
    if (depuracion)(*serialDepuracion).println(" ...No Cargada, Agrege Objeto Primero");
  }
}

void Interface::agregarVariableEstado(String nombreVariableEstado, bool (*apuntadorVariableEstado)) {
  if (depuracion) {
    (*serialDepuracion).print("Cargando Variable Estado: ");
    (*serialDepuracion).print(nombreVariableEstado);
  }
  // cargamos la funcion al vector de apuntadores a funciones
  if (objetoActual != "") {
    apuntadoresVariablesEstado[contadorVariablesEstadoCargadas] = apuntadorVariableEstado;    // guardamos el apuntador a la variable de estado
    nombreVariablesEstado[contadorVariablesEstadoCargadas] = nombreVariableEstado;            // guardamos el nombre de la variable de estado
    nombreObjetosVariablesEstado[contadorVariablesEstadoCargadas] = objetoActual;             // asignamos esta variable a un objeto
    VariablesEstadoAnterior[contadorVariablesEstadoCargadas] = *apuntadorVariableEstado;      // inicializamos para saber si cambia
    contadorVariablesEstadoCargadas++;
    if (depuracion)(*serialDepuracion).println(" ...Cargada");
  } else {
    if (depuracion)(*serialDepuracion).println(" ...No Cargada, Agrege Objeto Primero");
  }
}


void Interface::enviar_identificacion() {
  String modelo;
  // construimos nuestro modelo objetual en JSON y lo enviamos
  StaticJsonBuffer<200> jsonBuffer;
  JsonObject& root = jsonBuffer.createObject();
  byte j = 0;
  root["Objeto"] = nombreObjetos[j];      // cargamos el primer objeto
  // se cargan las funciones del objeto
  JsonArray& Funciones = root.createNestedArray("Funciones");
  for (byte i = 0; i < contadorFuncionesCargadas; i++) {
    if (nombreObjetosFuncion[i] == nombreObjetos[j]) {
      Funciones.add(nombreFunciones[i]);
    }
  }
  //JsonObject& nestedObject = root.createNestedObject();

  // enviamos la estructura JSON
  root.printTo(modelo);
  enviarMensaje(modelo);
  //delay(50);
}


String Interface::recivirStringNrf24l01() {
  // leemos un primer paquete
  String mensaje = recivirHasta32Nrf24l01();

  // si enviaron paquetes
  if (mensaje[0] == '-') {
    // son varios paquetes, obtengo el numero de paquetes
    byte numeroPaquetes = obtenerNumeroPaquetes(mensaje);

    // preguntamos aunque es obio
    if (numeroPaquetes > 0 ) {
      mensaje = "";       // limpiamos mensaje
      int contadorPaquetesRecibidos = 0;
      unsigned long tiempoInicioMensaje = millis();
      unsigned long maximoTiempoEspera = 200;     // lo que esperamos antes de cancelar el paquete
      while (contadorPaquetesRecibidos < numeroPaquetes && millis() < (tiempoInicioMensaje + maximoTiempoEspera)) {
        // armamos el paquete
        String paqueteLeido = recivirHasta32Nrf24l01();
        if (paqueteLeido != "") {
          mensaje += paqueteLeido;
          contadorPaquetesRecibidos++;
        }
      } // fin while varios paquetes

      // si el paquete no llego completo lo descartamos
      if (contadorPaquetesRecibidos < numeroPaquetes) {
        if (depuracion) {(*serialDepuracion).println("Paquete Incompleto");}
        return "";
      } else {
        return mensaje;
      }
    }// fin numero de paquetes mayor a 0

  } else {
    return mensaje;     // si no esta por paquetes, retornamos el mensaje recivido
  }
}

String Interface::recivirHasta32Nrf24l01() {

  radio.startListening();
  uint8_t len;
  char data[buffer_datos_recividos];
  String mensaje = "";

  if (radio.available()) {
    while (radio.available()) {             // While there is data ready
      len = radio.getDynamicPayloadSize();
      radio.read(&data, len);             // Get the payload
      mensaje = String(data).substring(0, len);
    }
    if (depuracion) {
      (*serialDepuracion).print("Recibido: #");
      (*serialDepuracion).print(len);
      (*serialDepuracion).print(" ");
      (*serialDepuracion).println(mensaje);
    }
    return mensaje;
  } else {
    return "";
  }
}


void Interface::enviarMensaje(String mensaje) {
  if (comunicacionNRF24L01) {
    // nos comunicamos a travez del modulo NRF24L01
    unsigned long tiempoReintentando = millis();
    while (!enviarStringNrf24l01(mensaje) && millis() < tiempoReintentando + 200) {}
    //delay(500);
  } else {
    // nos comunicamos por serial
  }
}

bool Interface::enviarStringNrf24l01(String mensaje) {
  // convertimos el string de salida a un arreglo de caracteres usado por radio.write
  unsigned int largoMensaje = mensaje.length();

  unsigned int numeroPaquetes  = largoMensaje / 32;
  if (largoMensaje % 32 > 0) {numeroPaquetes++;}

  if (numeroPaquetes > 1) {
    if (depuracion) {
      (*serialDepuracion).print(" Lm: ");
      (*serialDepuracion).print(largoMensaje);
      (*serialDepuracion).print(" #P: ");
      (*serialDepuracion).println(numeroPaquetes);
    }
    // envimos el paquete de inicio
    enviarHasta32CharNrf24l01("-" + String(numeroPaquetes) + "-");
  }
  for (int i = 0; i < numeroPaquetes; i++) {
    unsigned int fin  = (i + 1) * 32;
    if (fin >= largoMensaje) {
      fin = largoMensaje;   // para el ultimo paquete que no es de tama�o 32*i
    }
    String paquete = mensaje.substring(i * 32, fin);

    //bool noEnviado = true;
    unsigned long tiempoInicioMensaje = millis();
    unsigned long maximoTiempoEspera = 100;     // lo que esperamos antes de dejar de reenviar
    while (!enviarHasta32CharNrf24l01(paquete) && millis() < (tiempoInicioMensaje + maximoTiempoEspera)) {} // fin while reenvio

    if (!(millis() < (tiempoInicioMensaje + maximoTiempoEspera))) {
      if (depuracion)(*serialDepuracion).println("-Tiempo- Mensaje Cancelado");
      return false;   // canselamos el envio del paquete
    }
  } // fin for paquetes
  // si se logra enviar el mensaje completo
  return true;
}

bool Interface::enviarHasta32CharNrf24l01(String mensaje) {
  radio.stopListening();
  // convertimos el string de salida a un arreglo de caracteres usado por radio.write
  char datos[mensaje.length()];
  strncpy(datos, mensaje.c_str(), sizeof(datos));
  bool enviado = radio.write( &datos, sizeof(datos) );

  if (depuracion) {
    (*serialDepuracion).print("Enviando: #");
    (*serialDepuracion).print(mensaje.length());
    (*serialDepuracion).print(" ");
    (*serialDepuracion).print(mensaje);
    // enviamos los datos
    if (enviado) {
      (*serialDepuracion).println(F(" Exitoso"));
    } else {
      (*serialDepuracion).println(F(" Fallido"));
    }
  }
  return enviado;
}


void Interface::activarDepuracion(HardwareSerial& serial) {
  depuracion =  true;
  serialDepuracion = &serial;
  (*serialDepuracion).println("Depuracion Interfaz: Activada");
}

void Interface::usarNRF24L01() {
  comunicacionNRF24L01 = true;
  configurarRadioModulo();
}

void Interface::configurarRadioModulo() {
  radio.begin();
  // RF24_PA_MAX is default-> requiere capacitor
  radio.setPALevel(RF24_PA_LOW);
  radio.enableDynamicPayloads();
  // configuracion direcciones por defecto
  radio.openWritingPipe(addresses[0]);      // escribimos a la dirrecion de la interfaz por defecto
  radio.openReadingPipe(1, addresses[1]);   // escuchamos en nuestra direccion por defecto
}


int Interface::obtenerNumeroPaquetes(String paquete) {
  String numero = "";
  for (int i = 0; i < paquete.length(); i++) {
    if (paquete[i] != '-') {
      numero += paquete[i];
    }
  }
  return numero.toInt();
}

String Interface::uint64tostring(uint64_t numero) {
  String numerostring = "";
  uint64_t xx = numero / 1000000000ULL;

  if (xx > 0) numerostring = String((long)xx);
  numerostring += String((long)(numero - xx * 1000000000));
  return numerostring;
}

