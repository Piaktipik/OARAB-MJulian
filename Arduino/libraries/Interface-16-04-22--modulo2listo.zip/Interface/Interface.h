
#ifndef Interface_h
#define Interface_h

#include <SPI.h>
#include <ArduinoJson.h>
#include "nRF24L01.h"   // lista de constantes simbolicas modulo rf
#include "RF24.h"
#include "Arduino.h"
//#include <stdio.h>


// definicion de la clase Interface
class Interface {

public:
    Interface();
    void revisarInterface();

    void agregarObjeto(const String nombreObjeto, bool esHermano = false);
    void agregarFuncion(String nombreFuncion, void (*apuntadorFuncion)());
    void agregarVariableEstado(String nombreVariableEstado, bool (*apuntadorVariableEstado));

    void activarDepuracion(HardwareSerial& serial);
    void usarNRF24L01();

private:
    // variables otras clases
    HardwareSerial *serialDepuracion;
    RF24 radio;

    // variables propias
    bool depuracion;
    bool conectado;
    bool publicado;
    String objetoActual = "";
    // variables comunicacion modulo NRF24L01
    bool comunicacionNRF24L01;
    const uint64_t addresses[2] = {0xF0F0F0F0E1, 0xF0F0F0F0D2}; // direcciones por defecto del este modulo y de escucha
    //static uint64_t direcciones[];
    uint8_t buffer_datos_recividos;
    // variables manejo de funciones y objetos
    static const byte cantidadMaximaObjetos = 5;
    static const byte cantidadMaximaFunciones = 5;
    static const byte cantidadMaximaVariablesEstado = 5;
    byte contadorObjetosCargados = 0;
    byte contadorFuncionesCargadas = 0;
    byte contadorVariablesEstadoCargadas = 0;

    String nombreObjetos[cantidadMaximaObjetos];
    bool ObjetosHermanos[cantidadMaximaObjetos];

    String nombreObjetosFuncion[cantidadMaximaFunciones];
    String nombreObjetosVariablesEstado[cantidadMaximaVariablesEstado];

    String nombreFunciones[cantidadMaximaFunciones];
    String nombreVariablesEstado[cantidadMaximaVariablesEstado];
    bool (VariablesEstadoAnterior[cantidadMaximaVariablesEstado]);

    void (*apuntadoresFunciones[cantidadMaximaFunciones])();
    bool (*apuntadoresVariablesEstado[cantidadMaximaVariablesEstado]);

    // funciones privadas
    void publicacion();
    String procesarMensaje();
    String obtenerFuncionJson(String datos);

    void enviar_identificacion();

    String recivirStringNrf24l01();
    String recivirHasta32Nrf24l01();

    void enviarMensaje(String mensaje);
    bool enviarStringNrf24l01(String mensaje);
    bool enviarHasta32CharNrf24l01(String mensaje);

    void configurarRadioModulo();

    int obtenerNumeroPaquetes(String paquete);
    String uint64tostring(uint64_t numero);

};

#endif

